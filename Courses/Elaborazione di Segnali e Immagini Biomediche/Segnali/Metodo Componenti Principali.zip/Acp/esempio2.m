%Esempio di ACP di y=2*x+1 dove ho aggiunto un rumore gaussiano a y.

%2004 - Ing. Giulio Pravisani

clear
close all
disp('Variabili di partenza linearmente dipendenti y=2*x+1:')
x=[-1 1 3]
y=2*x+1
pause
disp('Aggiungo a y un rumore gaussiano di media nulla e varianza 1.5:')
y=y+1.5*randn(1,3)
pause
disp('Tabella:')
tabella=[x' y']
pause
acp(tabella,1,1)
