function []=acp(tabella,centra,riduci)

%Effettua una Analisi delle Componenti Principali su una tabella di 2 colonne.
%Si pu� scegliere se i dati devono essere centrati o ridotti. Se i dati non sono
%centrati si sta eseguendo un'analisi generale, NON UNA ACP.
%Per una buona rappresentazione grafica, non usare valori superiori a 10.
%ATTENZIONE!! L'orientamento degli assi principali � arbitrario perch� gli
%autovettori sono definiti a meno del segno.
%
%acp(tabella,centra,riduci)

%2004 - Ing. Giulio Pravisani

close all
[righe,colonne]=size(tabella);

if colonne>2
    error('ATTENZIONE!! Questa simulazione funziona solo con una tabella a 2 colonne.')
end

%centra e riduce i dati se richiesto
media=mean(tabella);
if centra & not(riduci)
    dati=tabella-repmat(media,righe,1);
    flag=1;
elseif riduci & not(centra)
    devst=std(tabella);
    dati=tabella./repmat(devst,righe,1);
    flag=2;
elseif centra & riduci
    dati=cr(tabella);
    flag=3;
else
    dati=tabella;
    flag=0;
end

%analisi componenti principali
xx=dati'*dati;
[autovettori,autovalori]=eig(xx);

%normalizza gli autovettori
[a,nautovettori]=size(autovettori);

for a=1:nautovettori
    autovettori(:,a)=autovettori(:,a)/norm(autovettori(:,a));
end

newdati=dati*autovettori;

%ordina autovettori rispetto agli autovalori crescenti
[autovalori,index] = sort(diag(autovalori));
autovettori = autovettori(:,index);
autovalori=flipud(autovalori);
autovettori=fliplr(autovettori);
inerzia=100*autovalori./sum(autovalori);

%esegui il plot dei dati originali nel rif princ
h=figure(1);
plot(tabella(:,1),tabella(:,2),'.')
line([0 1],[0 0])
line([0 0],[0 1])
title('Dati originali')
axis equal

if colonne==2
    axis([-10 10 -10 10])
end

pause

%esegui il plot dei dati (centrati e/o ridotti) e cerca l'asse che massimizza
%la varianza della proiezione, cio� l'asse che passa pi� vicino ai dati
h=figure(2);
pianoproiez=axes('position',[0.1 0.1 0.5 0.2]);
pianodistanza=axes('position',[0.7 0.1 0.2 0.8]);
pianodati=axes('position',[0.1 0.5 0.5 0.4]);
axes(pianodati)
plot(dati(:,1),dati(:,2),'.')
line([0 1],[0 0])
line([0 0],[0 1])
axis equal
axis tight

if colonne==2
    axis([-10 10 -10 10])
end

xlabel('Rappresentazione dei dati in funzione delle variabili')
alfa=[0:0.05:pi]; %provo l'asse inclinato in tutti i modi possibili
x=cos(alfa);
y=sin(alfa);
distanzamax=0;

for a=1:length(alfa)
    axes(pianodati)
    linea=line([-x(a) x(a)]*5000,[-y(a) y(a)]*5000);
    
    if colonne==2
        axis([-10 10 -10 10])
    end
    
    title([num2str(a) '/' num2str(length(alfa))])
    vettore=[x(a);y(a)]; %autovettore corrispondente all'angolo alfa
    proiezione=dati*vettore(:,1); %proiez dei dati su quel vettore
    varianza=var(proiezione); %varianza della proiezione
    distanza=proiezione'*proiezione; %somma delle distanze dei punti dallo zero
    axes(pianoproiez)
    plot(proiezione,zeros(length(proiezione)),'r.')
    line([-10 10],[0 0])
	xlabel('Proiezioni dei punti sull''asse rotante')
	axis([-10 10 -1 1])
    axes(pianodistanza)
    
    %memorizza la distanza massima
    if distanza>distanzamax
        distanzamax=distanza;
    end
    
    bar(distanza);
	xlabel('Sommatoria delle distanze proiettate')
    hmax=line([-1 1],[distanzamax distanzamax]);
    h=line([-1 1],[distanza distanza]);
    set(hmax,'color','r')
    axis([0.5 1.5 0 100])
    text(1,distanzamax,num2str(distanzamax))
    text(1,distanza,num2str(distanza))
    pause(0.2)
    delete(linea)
    delete(h)
end
pause

%cancella i grafici
%plot degli autovettori migliori
delete(pianodati)
delete(pianodistanza)
delete(pianoproiez)
plot(dati(:,1),dati(:,2),'.')
axis equal
axis([-10 10 -10 10])
line([0 autovettori(1,1)],[0 autovettori(2,1)]) %primo asse princ
line([0 autovettori(1,2)],[0 autovettori(2,2)]) %secondo asse princ

if autovettori(1,1)<0
    text(autovettori(1,1),autovettori(2,1),[num2str(autovalori(1)) '=' num2str(inerzia(1)) '%'],'horizontalalign','right')
    text(autovettori(1,2),autovettori(2,2),[num2str(autovalori(2)) '=' num2str(inerzia(2)) '%'],'horizontalalign','left')
else
    text(autovettori(1,1),autovettori(2,1),[num2str(autovalori(1)) '=' num2str(inerzia(1)) '%'],'horizontalalign','left')
    text(autovettori(1,2),autovettori(2,2),[num2str(autovalori(2)) '=' num2str(inerzia(2)) '%'],'horizontalalign','right')
end

switch flag
case 0
    title('Dati e assi fattoriali')
case 1
    title('Dati centrati e assi fattoriali principali')
case 2
    title('Dati ridotti e assi fattoriali')
case 3
    title('Dati centrati e ridotti e assi fattoriali principali')
end

pause

%esegui il plot dei dati riferiti agli assi fattoriali nel primo piano princ
%si nota come questo cambiamento di coord abbia semplicemente ruotato gli assi
h=figure(3);
plot(newdati(:,1),newdati(:,2),'.')
axis equal
line([0 1],[0 0]) %primo asse princ
line([0 0],[0 1]) %secondo asse princ
axis([-10 10 -10 10])
title('Primo piano fattoriale (ROTAZIONE)')
pause

%plot della percentuale cumulativa di inerzia spiegata
h=figure(4);
for a=1:colonne
    testo{a}=['Asse ' num2str(a) ':' num2str(autovalori(a)) '=' num2str(inerzia(a)) '%'];
end

pareto(inerzia,testo)
title('Inerzia spiegata dagli assi')