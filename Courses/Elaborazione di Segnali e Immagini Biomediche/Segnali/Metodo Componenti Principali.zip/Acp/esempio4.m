function esempio4()

%Esempio della ricostruzione di 8 derivazioni EEG con l'ACP

%2004 - Ing. Giulio Pravisani

close all
load dati.mat
tabella=dati';
[righe colonne]=size(tabella);
x=[0:1/fc:(righe-1)/fc];

%trova la media
media=repmat(mean(tabella),righe,1);

%calcola l'ACP
[autovettori proiezioni autovalori]=princomp(tabella);
varianzatotale=sum(autovalori);

%plot delle proiezioni (autosegnali) sugli assi principali
figure(1)
for a=1:colonne
    h=subplot(1,17,a);
    y=tabella(:,a);
    plot(y,x)
    set(h,'xlim',[-64 64]);
    axis ij
    set(h,'xtick',[],'xticklabel',[])
    if a~=1
        set(h,'ytick',[],'yticklabel',[])
    else
        ylabel('Tempo s')
    end
    title(elettrodi(a,1:3))
end
subplot(1,17,4)
xlabel('Dati originali')

for a=1:colonne
    h=subplot(1,17,a+9);
    y=proiezioni(:,a);
    plot(y,x)
    set(h,'xlim',[-64 64]);
    axis ij
    set(h,'xtick',[],'xticklabel',[])
    if a~=1
        set(h,'ytick',[],'yticklabel',[])
    else
        ylabel('Tempo s')
    end
    title([num2str(a) '/' num2str(colonne)])
end
subplot(1,17,13)
xlabel('Dati proiettati (autosegnali)')
pause

%ricostruisce i dati di partenza
figure(2)
for a=1:colonne
    h=subplot(1,26,a);
    y=tabella(:,a);
    plot(y,x)
    set(h,'xlim',[-64 64]);
    axis ij
    set(h,'xtick',[],'xticklabel',[])
    if a~=1
        set(h,'ytick',[],'yticklabel',[])
    else
        ylabel('Tempo s')
    end
    title(elettrodi(a,1:3))
end
subplot(1,26,4)
xlabel('Dati originali')

tabellaricostruita=zeros(righe,colonne)+media;
for a=1:colonne
    h=subplot(1,26,a+9);
    y=tabellaricostruita(:,a);
    plot(y,x)
    set(h,'xlim',[-64 64]);
    axis ij
    set(h,'xtick',[],'xticklabel',[])
    if a~=1
        set(h,'ytick',[],'yticklabel',[])
    else
        ylabel('Tempo s')
    end
    title(elettrodi(a,1:3))
end
subplot(1,26,13)
xlabel(['Dati ricostruiti 0/' num2str(colonne) ', Tasso inerzia: 0%'])

residui=tabella-tabellaricostruita;
for a=1:colonne
    h=subplot(1,26,a+18);
    y=residui(:,a);
    plot(y,x)
    set(h,'xlim',[-64 64]);
    axis ij
    set(h,'xtick',[],'xticklabel',[])
    if a~=1
        set(h,'ytick',[],'yticklabel',[])
    else
        ylabel('Tempo s')
    end
    title(elettrodi(a,1:3))
end
subplot(1,26,22)
xlabel('Errore')

for a=1:colonne
    pause
    autovettoritemp=autovettori(:,1:a);
    tabellaricostruita=media+proiezioni(:,1:a)*autovettoritemp';
    varianzaspiegata=100*sum(autovalori(1:a))/varianzatotale;
    residui=tabella-tabellaricostruita;
	for b=1:colonne
        h=subplot(1,26,b+9);
        y=tabellaricostruita(:,b);
        plot(y,x)
        set(h,'xlim',[-64 64]);
        axis ij
        set(h,'xtick',[],'xticklabel',[])
        if b~=1
            set(h,'ytick',[],'yticklabel',[])
        else
            ylabel('Tempo s')
        end
        title(elettrodi(b,1:3))
	end
    subplot(1,26,13)
    xlabel(['Dati ricostruiti ' num2str(a) '/' num2str(colonne) ', Tasso inerzia: ' num2str(varianzaspiegata) '%'])
	for b=1:colonne
        h=subplot(1,26,b+18);
        y=residui(:,b);
        plot(y,x)
        set(h,'xlim',[-64 64]);
        axis ij
        set(h,'xtick',[],'xticklabel',[])
        if b~=1
            set(h,'ytick',[],'yticklabel',[])
        else
            ylabel('Tempo s')
        end
        title(elettrodi(b,1:3))
    end
    subplot(1,26,22)
    xlabel('Errore')
end