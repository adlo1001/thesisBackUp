function esempio5(esempio)

%Dimostra che la PCA non va bene per separare segnali.
%Prende come esempio 3 rilevazioni di un
%segnale ECG corrotto da rumore di rete se esempio=1.
%Prende come esempio 3 segnali correlati linearmente se esempio=2.
%Prende come esempio 3 segnali non correlati lineamente se esempio=3.
%
%Esempio5(esempio)

close all

hertz=1;
if esempio==1
    load ecg.mat %ecg campionato a 200 Hz
    ecg=ecg*1000;
    ampiezza=[min(ecg) max(ecg)];
    base=[0:1/200:(length(ecg)-1)/200]; %base dei tempi, Fc=200 Hz
    rumore=sin(2*pi*hertz*base)*(ampiezza(2)-ampiezza(1))*0.2;
	figure
	subplot(211)
	plot(base,ecg)
    ylim(ampiezza)
	title('ECG a 200 Hz')
	subplot(212)
	plot(base,rumore)
    ylim(ampiezza)
	title(['RUMORE a ' num2str(hertz) ' Hz'])
	xlabel('secondi')
	pause
    %componenti misurate
    s1=(0.5*ecg+0.5*rumore);
    s2=(0.3*ecg+0.7*rumore);
end
if esempio==2
    s1=[1:200];
    s2=2*s1+randn(1,length(s1))*10;
    base=s1;
    ampiezza=[-10 410];
end
if esempio==3
    s1=[1:200];
    s2=sin(2*pi*s1*0.01)*100+randn(1,length(s1))+100;
    base=s1;
    ampiezza=[-100 410];
end    

tabella=[s1' s2'];
figure
subplot(211)
plot(base,tabella(:,1))
ylim(ampiezza)
title('Primo segnale')
subplot(212)
plot(base,tabella(:,2))
ylim(ampiezza)
title('Secondo segnale')
xlabel('secondi')
pause

%PCA i segnali sono in colonna
%PCA: il metodo si accorge che ci sono componenti dipendenti perch� un
%autovalore � nullo
%per� non elimina la componente dipendente. Le componenti originali non
%sono ben separate perch� questo metodo serve di pi� a vedere la
%covarianza (correlazione) fra le componenti che non ad isolarle.
[righe,colonne]=size(tabella);

%trova la media
media=repmat(mean(tabella),righe,1);

%calcola l'ACP
[autovettori proiezioni autovalori]=princomp(tabella);
varianzatotale=sum(autovalori);

%plot di confronto fra la distribuzione congiunta dei primi due segnali
%misurati e il primo piano principale (la pca fa passare gli assi lungo la
%minima inerzia/massima varianza che serve per ottenere delle componenti
%principali ma non indipendenti, infatti la disposizione non � rettangolare
%e non � parallela agli assi)
figure
subplot(121)
plot(tabella(:,1),tabella(:,2),'.')
axis equal
xlabel('Primo segnale misurato')
ylabel('Secondo segnale misurato')
title('DISTRIBUZIONE CONGIUNTA DEI PRIMI 2 SEGNALI MISURATI')
subplot(122)
plot(proiezioni(:,1),proiezioni(:,2),'.')
axis equal
xlabel(['Primo asse principale (inerzia=' num2str(autovalori(1)/varianzatotale*100) '%)'])
ylabel(['Secondo asse principale (inerzia=' num2str(autovalori(2)/varianzatotale*100) '%)'])
title('COMPONENTI PRINCIPALI')
pause

%plot delle proiezioni (autosegnali)
figure
for a=1:colonne
    h=subplot(colonne*2+1,1,a);
    plot(base,tabella(:,a))
    ylim(ampiezza)
    if a~=colonne
        set(h,'xtick',[],'xticklabel',[])
    end
    title([num2str(a) ' SEGNALE MISURATO'])
end
for a=1:colonne
    h=subplot(colonne*2+1,1,a+colonne+1);
    plot(base,proiezioni(:,a))
    ylim(ampiezza)
    if a~=colonne
        set(h,'xtick',[],'xticklabel',[])
    end
    title([num2str(a) '� COMPONENTE PRINCIPALE (inerzia=' num2str(autovalori(a)/varianzatotale*100) '%)'])
end
xlabel('secondi')