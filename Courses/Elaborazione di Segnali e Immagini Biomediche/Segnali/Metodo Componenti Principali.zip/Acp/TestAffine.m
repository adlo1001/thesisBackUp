function TestAffine()

%Valuta il significato di ogni singolo valore dei 4 possibili nella matrice
%della trasformazione affine cambiandone uno alla volta e lasciando gli
%altri uguali all'elemento neutro [1 0;0 1];

close all

%cambia il primo valore, ottengo uno stiramento orizzontale (trazione
%orizzontale)
for i=-3:0.1:3
    affine(i,0,0,1,0,0);
end

%cambia il secondo valore, ottengo uno stiramento orizzontale in due
%direzioni opposte (taglio orizzontale)
for i=-3:0.1:3
    affine(1,i,0,1,0,0);
end

%cambia il terzo valore, ottengo uno stiramento verticale in due direzioni
%opposte (taglio verticale)
for i=-3:0.1:3
    affine(1,0,i,1,0,0);
end

%cambia il quarto valore, ottengo uno stiramento verticale (trazione
%verticale)
for i=-3:0.1:3
    affine(1,0,0,i,0,0);
end

%cambia il quinto valore, ottengo una traslazione orizzontale
for i=-3:0.1:3
    affine(1,0,0,1,i,0);
end

%cambia il sesto valore, ottengo una traslazione verticale
for i=-3:0.1:3
    affine(1,0,0,1,0,i);
end

function affine(a11,a12,a21,a22,b1,b2)

base=[-4:4];
assi=[-15 15 -15 15];
[x,y]=meshgrid(base); %crea tutti i punti della griglia di partenza
x=x(:)'; %li trasforma in vettori riga
y=y(:)'; %li trasforma in vettori riga

%applica la trasformazione affine
matrice=[a11 a12;a21 a22];
griglia=[x;y];
traslazione=[b1;b2];
X=matrice*griglia+repmat(traslazione,1,length(base)^2);

figure(1)
plot(x,y,'.') %plot della griglia di partenza
axis equal
axis(assi)
hold on
plot(X(1,:),X(2,:),'.r') %plot della griglia trasformata
title(['GRIGLIA TRASFORMATA [' num2str(a11) ',' num2str(a12) ',' num2str(a21) ',' num2str(a22) ',' num2str(b1) ',' num2str(b2) ']'])
axis equal
axis(assi)
hold off
pause(0.1)
