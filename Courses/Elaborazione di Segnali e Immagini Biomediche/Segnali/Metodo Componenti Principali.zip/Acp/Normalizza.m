function [out]=Normalizza(in,ValMin,ValMax)

%Normalizza un vettore di dati in ingresso in modo tale che abbia il massimo e il minimo pari ai valori immessi.
%
%[out]=Normalizza(in,min,max)

massimo=max(in);
minimo=min(in);
delta=(ValMax-ValMin)/(massimo-minimo);

q=ValMin-minimo*delta;
out=in*delta+q;