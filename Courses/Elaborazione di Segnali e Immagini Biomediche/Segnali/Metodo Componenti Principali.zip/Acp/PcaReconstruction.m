function []=PcaReconstruction(ImSet)

%Esempio della ricostruzione di immagini utilizzando dei visi (ImSet=1) o
%figure di oggetti variegati (ImSet=2).
%
%PcaReconstruction(ImSet)

close all

if ImSet>2
    error('ERRORE: ImSet=1 facce, ImSet=2 oggetti!!')
end
if ImSet==1
    stringa='face';
end
if ImSet==2
    stringa='obj';
end
anfang = 11; %immagine di partenza
M = 18; %numero totale di immagini caricate
load map; %mappa di colore

%ricava le dimensioni delle immagini
file = strcat(stringa,'11.bmp');
im = imread(file);
[dim1,dim2]=size(im);

%carica le immagini (da 11 a 28) nelle colonne della matrice x
x = zeros(dim1*dim2, M);
j=1;
for i=anfang:1:anfang+M-1
    inum = num2str(i);
    file = strcat(stringa, inum, '.bmp');
    im = imread(file);
    f = double(im);
    x(:,j) = reshape(f,dim1*dim2,1);
    j = j+1;
end

%plot delle immagini
figure
for i=1:min(M,18)
    subplot(3,6,i)
    imshow(reshape(x(:,i), dim1,dim2),map);
    title(sprintf('Immagine %d/%d',i,M));
end
pause

%la matrice m ha dim1*dim2 righe e NumImmagini colonne
%calcola l'immagine media
m = mean(x,2);

%plot dell'immagine media
figure
imshow(reshape(m,dim1,dim2),map);
title('Immagine media')
pause

%centra le immagini (sottrae la media alle immagini)
diff = zeros(dim1*dim2, M);
for k=1:M
    diff(:,k) = x(:,k) - m;
end

%visualizza le immagini centrate
figure
for i=1:min(M,18)
    subplot(3,6,i)
    imagesc(reshape(diff(:,i), dim1,dim2));
    set(gca, 'XTick',[],'YTick',[]);
    colormap(map);
%    set(gca,'Visible','off');
    title(sprintf('Immagine %d/%d centrata',i,M));
    axis equal
end
pause

%calcolo della PCA
L = diff'*diff;
[eigenvector, eigenvalue] = eig(L);

%ordina autovalori e autovettori
[sorted_values,index] = sortrows(eigenvalue');
evalue = zeros(M,1);
for i=1:M
    evalue(i,1) = eigenvalue(i,i);
end
[sorted_value,index] = sort(evalue,1);
sorted_value = flipud(sorted_value);
index = flipud(index);
sorted_evector = eigenvector(:,index);

%proietto le immagini centrate sugli autovettori (trovo le nuove componenti
%rispetto ai nuovi assi fattoriali)
eigenfaces = diff * sorted_evector;

%normalizzazione
nfaces = zeros(dim1*dim2,M);
for i=1:M
    nfaces(:,i) =eigenfaces(:,i) / sqrt(sum(eigenfaces(:,i).^2));
end

%plot delle autoimmagini (immagini proiettate sugli autovettori)
%con autovalori decrescenti
figure
for i=1:min(M,18)
    subplot(3,6,i)
    imagesc(reshape(nfaces(:,i), dim1,dim2));
    set(gca, 'XTick',[],'YTick',[]);
    colormap(map);
%    set(gca,'Visible','off');
    axis equal
    title(sprintf('Autoimmagine %d/%d',i,M));
end
pause

%CASO 1: ricostruzione di un'immagine presente fra quelle di partenza
newfile = strcat(stringa,'12.bmp');
im = double(imread(newfile));
v = reshape(im,dim1*dim2,1);

w = nfaces' * (v - m); %proiezione delle autoimmagini sull'immagine di test centrata
%nfaces � dim1*dim2xNumImmagini, v � dim1*dim2x1, m � dim1*dim2x1, quindi w
%� NumImmaginix1

%ricostruzione
figure
subplot(1,2,1)
imshow(reshape(im,dim1,dim2),map)
title(sprintf('Immagine originale'));
recons = zeros(dim1*dim2,1);
for i=1:18
    subplot(1,2,2)
    imshow(reshape(recons+m,dim1,dim2),map)
    title(sprintf('Ricostruzione con %d/%d autoimmagini',i,M));
    recons = recons + w(i,1)*nfaces(:,i);
    pause
end

%CASO 2: ricostruzione di un'immagine simile alle immagini di partenza
newfile = strcat(stringa,'34.bmp');
im = double(imread(newfile));
v = reshape(im,dim1*dim2,1);

w = nfaces' * (v - m);

%ricostruzione
figure
subplot(1,2,1)
imshow(reshape(im,dim1,dim2),map)
title(sprintf('Immagine originale'));
recons = zeros(dim1*dim2,1);
for i=1:18
    subplot(1,2,2)
    imshow(reshape(recons+m,dim1,dim2),map)
    title(sprintf('RIcostruzione con %d/%d Autoimmagini',i,M));
    recons = recons + w(i,1)*nfaces(:,i);
    pause
end

%CASO 3: ricostruzione di un'immagine diversa dalle immagini di partenza
newfile = strcat(stringa,'auto_gray.bmp');
im = double(imread(newfile));
v = reshape(im,dim1*dim2,1);

w = nfaces' * (v - m);

%ricostruzione
figure
subplot(1,2,1)
imshow(reshape(im,dim1,dim2),map)
title(sprintf('Immagine originale'));
recons = zeros(dim1*dim2,1);
for i=1:18
    subplot(1,2,2)
    imshow(reshape(recons+m,dim1,dim2),map)
    title(sprintf('ricostruzione con %d/%d autoimmagini',i,M));
    recons = recons + w(i,1)*nfaces(:,i);
    pause
end