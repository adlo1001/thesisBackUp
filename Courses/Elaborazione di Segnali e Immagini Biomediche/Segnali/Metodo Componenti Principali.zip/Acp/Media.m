function []=Media()

%calcolo della media di punti in 1 e 2D.

close all
n=100;
x=randn(1,100);
y=randn(1,100);

%1D
for i=1:n
    plot(x(i),0,'.')
    xlim([min(x) max(x)])
    mediax=mean(x(1:i));
    mediay=0;
    hold on
    h1=plot(mediax,mediay,'Or');
    h2=text(mediax,mediay,'  Baricentro');
    pause(0.1)
    delete(h1)
    delete(h2)
end
plot(mediax,mediay,'Or')
text(mediax,mediay,'  Baricentro')
hold off
pause

%2D
for i=1:n
    plot(x(i),y(i),'.')
    xlim([min(x) max(x)])
    ylim([min(y) max(y)])
    mediax=mean(x(1:i));
    mediay=mean(y(1:i));
    hold on
    h1=plot(mediax,mediay,'Or');
    h2=text(mediax,mediay,'  Baricentro');
    pause(0.1)
    delete(h1)
    delete(h2)
end
plot(mediax,mediay,'Or')
text(mediax,mediay,'  Baricentro')
