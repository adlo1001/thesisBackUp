%Esempio di ricostruzione di un'immagine

%2004 - Ing. Giulio Pravisani

load clown
ricostruzione(X,map);