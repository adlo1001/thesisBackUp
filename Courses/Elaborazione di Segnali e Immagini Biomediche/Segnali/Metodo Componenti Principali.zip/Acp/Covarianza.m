function []=Covarianza()

%calcolo della covarianza/correlazione di punti in 2D (caso bivariato).

close all
n=100;
x=[0:20];

%caso correlato lineare
for i=-.5:0.01:.5
    y=i.*x;
    subplot(121)
    hold off
    plot(x,y,'.')
    hold on
    xlim([min(x) max(x)])
    ylim([-15 15])
    covarianza=cov(x',y'); %prendere il coeff (1,2)
    correlazione=corrcoef(x',y'); %prendere il coeff (1,2)
    h=subplot(122);
    bar([covarianza(1,2) correlazione(1,2)])
    ylim([-20 20])
    set(h,'xticklabel','Covarianza|Correlazione')
    pause(0.1)
end
pause

%caso correlato lineare con rumore
for i=-.2:0.01:.2
    y=i.*(x+2*randn(1,length(x)));
    subplot(121)
    hold off
    plot(x,y,'.')
    hold on
    xlim([min(x) max(x)])
    ylim([-10 10])
    covarianza=cov(x',y'); %prendere il coeff (1,2)
    correlazione=corrcoef(x',y'); %prendere il coeff (1,2)
    h=subplot(122);
    bar([covarianza(1,2) correlazione(1,2)])
    ylim([-8 8])
    set(h,'xticklabel','Covarianza|Correlazione')
    pause(0.1)
end
pause

%caso incorrelato
n=100;
x=randn(1,100);
y=rand(1,100);
for i=2:n
    covarianza=cov(x(1:i)',y(1:i)');
    correlazione=corrcoef(x(1:i)',y(1:i)');
    subplot(121)
    plot(x(i),y(i),'.')
    xlim([min(x) max(x)])
    ylim([min(y) max(y)])
    hold on
    h=subplot(122);
    bar([covarianza(1,2) correlazione(1,2)])
    ylim([-2 2])
    set(h,'xticklabel','Covarianza|Correlazione')
    pause(0.1)
end
