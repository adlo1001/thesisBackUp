%Esempio di calcolo di assi fattoriali

%2004 - Ing. Giulio Pravisani

close all
clear
disp('Tabella di partenza:')
dati=[1 2;1 7;3 2]

%per semplicit� usa solo 2 colonne
[righe,colonne]=size(dati);
if colonne~=2
    error('ATTENZIONE!! Questo demo funziona solo con una tabella di 2 colonne.')
end

disp('Tabella trasposta:')
xp=dati'
pause
disp('Moltiplico x''*x:')
xpx=dati'*dati
pause
syms a
disp('Diagonalizzo:')
m=xpx-diag([1 1])*a;
pretty(m)
pause
disp('Determinante:')
determinante=det(m);
pretty(determinante)
pause
disp('Autovalori:')
autovalori=solve(determinante,'a');
pretty(autovalori)
autovalori=vpa(autovalori,4)
pause
disp('Autovettori:')
syms x y real
sistema1=xpx*[x y]'-autovalori(1)*[x y]';
sistema2=xpx*[x y]'-autovalori(2)*[x y]';
collect(sistema1)
collect(sistema2)
autovettore1=solve(sistema1(1),'x');
autovettore2=solve(sistema2(1),'x');
autovettore1=vpa(autovettore1,4);
autovettore2=vpa(autovettore2,4);
autovettore1(2)=y
autovettore2(2)=y
pause
disp('Normalizzo:')
coeff1=subs(autovettore1,y,1);
coeff2=subs(autovettore2,y,1);
norma1=sum(abs(coeff1).^2)^0.5*y;
norma2=sum(abs(coeff2).^2)^0.5*y;
autovettore1=vpa(autovettore1./norma1,4)
autovettore2=vpa(autovettore2./norma2,4)
pause
disp('Nuove coordinate:')
dati1=dati*autovettore1'
dati2=dati*autovettore2'

%visualizzazione grafica
acp(dati,0,0)