function []=Varianza()

%calcolo della varianza di punti in 1 e 2D.

close all
n=100;
x=randn(1,100);
y=randn(1,100);

%1D
for i=1:n
    plot(x(i),0,'.')
    xlim([min(x) max(x)])
    mediax=mean(x(1:i));
    mediay=0;
    varianzax=var(x(1:i));
    varianzay=0;
    hold on
    h1=plot(mediax,mediay,'Or');
    h2=text(mediax,mediay,'  Baricentro');
    h3=line([mediax-varianzax mediax-varianzax],[-1 1]);
    h4=line([mediax+varianzax mediax+varianzax],[-1 1]);
    pause(0.1)
    delete(h1)
    delete(h2)
    delete(h3)
    delete(h4)
end
plot(mediax,mediay,'Or');
text(mediax,mediay,'  Baricentro');
line([mediax-varianzax mediax-varianzax],[-1 1])
line([mediax+varianzax mediax+varianzax],[-1 1])
hold off
pause

%2D
for i=1:n
    plot(x(i),y(i),'.')
    xlim([min(x) max(x)])
    ylim([min(y) max(y)])
    mediax=mean(x(1:i));
    mediay=mean(y(1:i));
    varianzax=var(x(1:i));
    varianzay=var(y(1:i));
    hold on
    h1=plot(mediax,mediay,'Or');
    h2=text(mediax,mediay,'  Baricentro');
    h3=line([mediax-varianzax mediax-varianzax],[min(y) max(y)]);
    h4=line([mediax+varianzax mediax+varianzax],[min(y) max(y)]);
    h5=line([min(x) max(x)],[mediay-varianzay mediay-varianzay]);
    h6=line([min(x) max(x)],[mediay+varianzay mediay+varianzay]);
    pause(0.1)
    delete(h1)
    delete(h2)
    delete(h3)
    delete(h4)
    delete(h5)
    delete(h6)
end
plot(mediax,mediay,'Or');
text(mediax,mediay,'  Baricentro');
line([mediax-varianzax mediax-varianzax],[min(y) max(y)])
line([mediax+varianzax mediax+varianzax],[min(y) max(y)])
line([min(x) max(x)],[mediay-varianzay mediay-varianzay])
line([min(x) max(x)],[mediay+varianzay mediay+varianzay])
