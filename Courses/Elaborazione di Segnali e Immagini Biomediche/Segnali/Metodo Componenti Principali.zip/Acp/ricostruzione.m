function []=ricostruzione(tabella,mappacolori)

%Da una tabella ricava le componenti principali, poi ricostruisce la tabella
%originale utilizzando man mano tutte le componenti principali. Alla fine
%la tabella ricostruita deve essere "riportata" nella posizione originale
%per avere gli stessi dati di partenza (gli deve essere risommata la media).
%NON E' uguale fare la media per righe o per colonne. La media per colonne
%non d� errore di ricostruzione, la media per righe s�.
%ricostruzione(tabella,mappacolori)

%2004 - Ing. Giulio Pravisani

close all

[righe,colonne]=size(tabella);
climite=[min(min(tabella)) max(max(tabella))];

%trova la media
media=repmat(mean(tabella),righe,1);

%calcola l'ACP
[autovettori proiezioni autovalori]=princomp(tabella);
varianzatotale=sum(autovalori);

%qui non ha molto senso visualizzare le proiezioni dell'immagine sugli
%autovettori, perch� otterrei dei vettori e non delle immagini
%imagesc(proiezioni,climite)

%ricostruisce i dati di partenza
figure(1);
colormap(mappacolori)
h=subplot(311);
imagesc(tabella,climite)
axis equal
axis tight
set(h,'xtick',[],'ytick',[])
title('Dati originali')
tabellaricostruita=zeros(righe,colonne)+media;
h=subplot(312);
imagesc(tabellaricostruita,climite);
axis equal
axis tight
set(h,'xtick',[],'ytick',[])
title(['Dati ricostruiti 0/' num2str(colonne)])
xlabel(['Tasso inerzia: 0%'])
residui=tabella-tabellaricostruita;
h=subplot(313);
imagesc(residui,climite)
axis equal
axis tight
set(h,'xtick',[],'ytick',[])
title('Errore')

for a=1:colonne
    pause
    h=subplot(312);
    autovettoritemp=autovettori(:,1:a);
    tabellaricostruita=media+proiezioni(:,1:a)*autovettoritemp';
    varianzaspiegata=100*sum(autovalori(1:a))/varianzatotale;
    residui=tabella-tabellaricostruita;
    imagesc(tabellaricostruita,climite)
    axis equal
    axis tight
    set(h,'xtick',[],'ytick',[])
    title(['Dati ricostruiti ' num2str(a) '/' num2str(colonne)])
    xlabel(['Tasso inerzia: ' num2str(varianzaspiegata) '%'])
    h=subplot(313);
    imagesc(residui,climite)
    axis equal
    axis tight
    set(h,'xtick',[],'ytick',[])
    title('Errore')
end
pause

figure
colormap(mappacolori)
imagesc(proiezioni,climite)
title('Proiezioni in colonna dell''immagine originale su ciascun autovettore')