function tabout=cr(tabin)

%Trasforma una tabella in entrata in una tabella centrata e ridotta.
%Ad ogni valore viene sottratta la media della colonna ed il tutto � diviso
%per la deviazione standard della colonna.

%2004 - Ing. Giulio Pravisani

[righe colonne]=size(tabin);
devstd=std(tabin,1) %divide std per N e non per N-1 perch� immaginiamo di avere tutti i dati e non solo una parte
media=mean(tabin)
tabout=(tabin-repmat(media,righe,1))./repmat(devstd,righe,1);