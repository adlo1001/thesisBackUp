function affine(a11,a12,a21,a22,b1,b2)

%Visualizza graficamente una trasformazione affine. Risolve il sistema
%X = a11 * x + a12 * y + b1
%Y = a21 * x + a22 * y + b2
%che in notazione matriciale diventa
%|X| = |a11 a12| * |x| + |b1|
%|Y|   |a21 a22|   |y|   |b2|
%
%Il grafico va da -15 a 15 quindi cercare di inserire numeri non troppo
%grandi.
%
%NOTE:
%1)se a11 * a22 - a21 * a12 = 0 la trasformazione non � reversibile e la
%matrice viene schiacciata su una retta
%2)se M = |0 0| tutto si concentra nel punto X = b1 e Y = b2
%         |0 0|
%2)se M = |1 0| � una traslazione di b1 sull'asse x e b2 sull'asse y
%         |0 1|
%Per semplicit� d'ora in poi considereremo b1 e b2 nulli.
%3)se M = |K 0| � una omotetia (zoom)
%         |0 K|
%4)se M = |cos a -sin a| � una rotazione antioraria dell'angolo a
%         |sin a  cos a|
%5)se M = | a1 a2| oppure M = |a1  a2| � una similitudine (zoom+rotazione)
%         |-a2 a1|            |a2 -a1|
%
%Nel caso non ci sia traslazione, calcola autovettori e autovalori e li
%disegna.
%
%Affine(a11,a12,a21,a22,b1,b2)

close all

base=[-4:4];
assi=[-15 15 -15 15];
[x,y]=meshgrid(base); %crea tutti i punti della griglia di partenza
x=x(:)'; %li trasforma in vettori riga
y=y(:)'; %li trasforma in vettori riga

%applica la trasformazione affine
matrice=[a11 a12;a21 a22];
griglia=[x;y];
traslazione=[b1;b2];
X=matrice*griglia+repmat(traslazione,1,length(base)^2);

figure(1)
plot(x,y,'.') %plot della griglia di partenza
title('GRIGLIA DI PARTENZA')
xlabel('X')
ylabel('Y')
axis equal
axis(assi)
pause
hold on
plot(X(1,:),X(2,:),'.r') %plot della griglia trasformata
title('GRIGLIA TRASFORMATA')
axis equal
axis(assi)
pause
distanze=sqrt((X(1,:)-x).^2+(X(2,:)-y).^2);
massimo=max(max(distanze))*85/100;
for i=0.1:0.1:massimo
    h=quiver(x,y,X(1,:)-x,X(2,:)-y,i); %plot delle frecce di spostamento
    pause(.1)
    delete(h)
end
quiver(x,y,X(1,:)-x,X(2,:)-y,0)
title('FRECCE')

%calcola gli autovalori/vettori
%notare che se � una rotazione pura gli autovalori/vettori sono immaginari
%e corrispondono all'asse di rotazione (che esce perpendicolarmente quindi
%dal piano x-y)
if b1==0 & b2==0
    [autovettori,autovalori]=eig(matrice)
    autovet1x=autovettori(1,1);
    autovet1y=autovettori(2,1);
    autovet2x=autovettori(1,2);
    autovet2y=autovettori(2,2);
    autoval1=autovalori(1,1);
    autoval2=autovalori(2,2);
    if isreal(autovettori)
        quiver(0,0,autoval1*autovet1x,autoval1*autovet1y,0,'k')
        quiver(0,0,autoval2*autovet2x,autoval2*autovet2y,0,'k')
    end
    pause
    title('AUTOVETTORI E AUTOVALORI')
    figure(2)
    plot(x,y,'.')
    hold on
    plot(X(1,:),X(2,:),'.r') %plot della griglia trasformata
    if isreal(autovettori)
        quiver(0,0,autoval1*autovet1x,autoval1*autovet1y,0,'k')
        quiver(0,0,autoval2*autovet2x,autoval2*autovet2y,0,'k')
        text(autoval1*autovet1x,autoval1*autovet1y,num2str(autoval1))
        text(autoval2*autovet2x,autoval2*autovet2y,num2str(autoval2))
    end
    axis equal
    axis(assi)
    title('FINE')
end