load ecg1.mat

X=ecg1(1001:10000);
N=length(X);
time=[1:N]'/250;
fc=250;
%%
figure(1);
subplot(3,1,1);plot(time,X);  axis tight;XLabel('time (sec)');title('ECG');box off;

w = waitforbuttonpress;
x=fft(X);
Px=x.*conj(x)/N;
freq=[0:fc/N:fc-1/N]';

subplot(3,1,2);plot(freq(1:N/2),abs(x(1:N/2)));axis tight;XLim([0 5]);XLabel('frequency Hz');YLabel('FT');box off;
w = waitforbuttonpress;
subplot(3,1,3);loglog(freq(1:N/2),(Px(1:N/2)).^10);XLabel('frequency Hz');Ylabel('PSD (dB)');axis tight
tick=[0.1 1 10 100];
set(gca,'XTick',tick,'XTickLabel',{'0.1','1','10','100'});box off;



%%
y=randn(N,1);
Y=(y./std(y))*(0.3*std(X));
Y=Y-mean(Y);

Xnoise=X+Y;
w = waitforbuttonpress;
figure(2);
subplot(3,1,1);plot(time,Xnoise);axis tight;XLabel('time (sec)');title('ECG + random noise');box off;
xN=fft(Xnoise);
PxN=xN.*conj(xN)/N;
w = waitforbuttonpress;
subplot(3,1,2);plot(freq(1:N/2),abs(xN(1:N/2)));axis tight;XLim([0 5]);XLabel('frequency Hz');Ylabel('FT');box off;
w = waitforbuttonpress;
subplot(3,1,3);loglog(freq(1:N/2),(PxN(1:N/2)).^10);XLabel('frequency Hz');Ylabel('PSD (dB)');axis tight
tick=[0.1 1 10 100];
set(gca,'XTick',tick,'XTickLabel',{'0.1','1','10','100'});box off;

%%

y=sin(2*pi*50*time);
Xnoise1=X+y*(0.3*std(X));
w = waitforbuttonpress;
figure(3);
subplot(3,1,1);plot(time,Xnoise1); axis tight;XLabel('time (sec)');title('ECG + Intererence at 50Hz');box off;
xN=fft(Xnoise1);
PxN=xN.*conj(xN)/N;

w = waitforbuttonpress;
subplot(3,1,2);plot(freq(1:N/2),abs(xN(1:N/2)));axis tight;XLim([0 70]);XLabel('frequency Hz');Ylabel('FT');box off;
w = waitforbuttonpress;
subplot(3,1,3);loglog(freq(1:N/2),(PxN(1:N/2)).^10);XLabel('frequency Hz');Ylabel('PSD (dB)');axis tight;box off;
tick=[0.1 1 10 100];
set(gca,'XTick',tick,'XTickLabel',{'0.1','1','10','100'});
