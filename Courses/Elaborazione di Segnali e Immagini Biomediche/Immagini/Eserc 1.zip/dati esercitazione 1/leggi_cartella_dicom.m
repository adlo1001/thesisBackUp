function volume=leggi_cartella_dicom;

dicomfiles=dir('testa_collo\*.dcm');
Nfiles=length(dicomfiles);
for i=1:Nfiles
    Y = dicomread(['testa_collo\',dicomfiles(i).name]);
    if i==1
        volume=Y;
    else
        volume=cat(3, volume, Y);
    end;
end;
