% N = dimensione di A
% TETA = tilt cosinusoide rispetto all'asse x in rad
% FREQ = freq. spaziale in cicli/campione (1/FREQ=campioni per ciclo)
% FI = fase cosinusoide (e.g. : o=cos; -pi/2=sin)

function A=immcos(amp,N,TETA,FREQ,FI);
WX=2*pi*cos(TETA)*FREQ; % pulsazione lungo l'asse x
WY=2*pi*sin(TETA)*FREQ; % pulsazione lungo l'asse y
for IX=1:N,
	for IY=1:N,
		ICOL=IX; % l'indice di colonna rappresenta la x
		IRIGA=IY; % l'indice di riga rappresenta la y
		A(IRIGA,ICOL)=amp*cos(WX*IX+WY*IY+FI);
	end
end
